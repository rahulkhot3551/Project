package service;

import bean.Customer;
import dao.DaoAccountClass;
import exception.BankException;

public class ServiceAccClass implements ServiceAccIntf {

	DaoAccountClass dao=new DaoAccountClass();
	
	@Override
	public void storeDetails(Customer c) {
	
		dao.beginTransaction();
		dao.storeDetails(c);
		dao.commitTransaction();
	}

	@Override
	public Customer getDetails(int account_num) throws BankException {

		return dao.getDetails(account_num);
	}

	@Override
	public boolean checkAccount(int account_number) {

		return dao.checkAccount(account_number);
	}

	@Override
	public Customer deposit(int ac_no, double amtDeposit) throws BankException {
		dao.beginTransaction();
		Customer cust= dao.deposit(ac_no, amtDeposit);
		dao.commitTransaction();
		return cust;
	}

	@Override
	public Customer withdraw(int acc_num, double withdraw) throws BankException {
		dao.beginTransaction();
	Customer cust=	dao.withdraw(acc_num, withdraw);
		dao.commitTransaction();
		return cust;
	}

	@Override
	public void fundTransfer(int acc1, int acc2, double amt) throws BankException {
		dao.beginTransaction();
		dao.fundTransfer(acc1, acc2, amt);
		dao.commitTransaction();
		
		
	}

}
