package service;

import bean.Customer;
import exception.BankException;

public interface ServiceAccIntf {
	void storeDetails(Customer c);
	Customer getDetails(int account_num) throws BankException;
	boolean	checkAccount(int account_number);

	Customer deposit(int ac_no , double amtDeposit) throws BankException;

	Customer withdraw(int acc_num , double withdraw) throws BankException;

	
	void fundTransfer(int acc1, int acc2 , double amt) throws BankException;

}
