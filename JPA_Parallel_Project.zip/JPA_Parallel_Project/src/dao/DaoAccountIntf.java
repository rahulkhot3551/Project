package dao;

import bean.Customer;
import exception.BankException;

public interface DaoAccountIntf {

	void storeDetails(Customer customer);		
	public abstract void beginTransaction();
	public abstract void commitTransaction();
	Customer getDetails(int account_num) throws BankException;

	boolean checkAccount(int account_number);
	Customer deposit(int ac_no , double amtDeposit) throws BankException;

	Customer withdraw(int acc_no , double withdraw) throws BankException;

	
	void fundTransfer(int acc1, int acc2 , double amt) throws BankException;

}
