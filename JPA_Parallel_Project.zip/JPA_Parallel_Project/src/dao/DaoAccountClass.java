package dao;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;

import bean.Customer;
import exception.BankException;

public class DaoAccountClass implements DaoAccountIntf {

	Map<Integer,Integer> map=new HashMap<Integer,Integer>();

static	DaoAccountClass daoClass=new DaoAccountClass();
	
	private EntityManager entityManager;
	public DaoAccountClass(){
		entityManager = Util.getEntityManager();

	}
	
	
	@Override
	public void storeDetails(Customer customer) {
		
		entityManager.persist(customer);

		map.put(customer.getAcct().getAcc_no(),customer.getCust_no());
	}

	
	@Override
	public void beginTransaction() {

		entityManager.getTransaction().begin();

		
	}

	@Override
	public void commitTransaction() {

		entityManager.getTransaction().commit();
		
	}


	@Override
	public Customer getDetails(int account_num) throws BankException {
	
		int cust=map.get(account_num);
		
		Customer  customerObject=entityManager.find(Customer.class, cust);
				
		return customerObject;
	}


	@Override
	public boolean checkAccount(int account_number) {

		return map.containsKey(account_number);

		}


	@Override
	public Customer deposit(int ac_no, double amtDeposit) throws BankException {

	Customer cust=	getDetails(ac_no);
	double account_balance=cust.getAcct().getAcc_balance();
	
	account_balance=account_balance+amtDeposit;
	cust.getAcct().setAcc_balance(account_balance);
	
	String details="Deposit Amount"+amtDeposit;
	cust.getAcct().setTransactionDetails(details);
	
	entityManager.merge(cust);
	
		return cust;
	}


	@Override
	public Customer withdraw(int acc_no, double withdraw) throws BankException {

		Customer cust=	getDetails(acc_no);
		double account_balance=cust.getAcct().getAcc_balance();
		
		
		account_balance=account_balance-withdraw;
		cust.getAcct().setAcc_balance(account_balance);

		String details="Withdrawn Amount"+withdraw;
		
		cust.getAcct().setTransactionDetails(details);
		
		entityManager.merge(cust);
		return cust;
	}


	@Override
	public void fundTransfer(int acc1, int acc2, double amt) throws BankException {
		
		Customer cust1=	getDetails(acc1);
		Customer cust2=	getDetails(acc2);

		
		double account_balance1=cust1.getAcct().getAcc_balance();
		double account_balance2=cust2.getAcct().getAcc_balance();
		
		cust1.getAcct().setAcc_balance(account_balance1-amt);
		cust2.getAcct().setAcc_balance(account_balance2+amt);
		
		String details="Deposit Amount "+amt;
		cust2.getAcct().setTransactionDetails(details);
	
		
	String details1="Withdrawn Amount "+amt;
		
		cust1.getAcct().setTransactionDetails(details1);
	
	entityManager.merge(cust1);
	entityManager.merge(cust2);

	}

}
