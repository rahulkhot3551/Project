package bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.metamodel.StaticMetamodel;


enum accType{
	SAVINGS,CURRENT;
}

@Embeddable
public class Account implements Serializable {
	
	private  int acc_no;
	
	@Enumerated(EnumType.STRING)
	@Column(name="acc_type")
	private accType type;
	private double acc_balance;
	private String transactionDetails=" ";
	
	public Account() {
		super();
		
		
	}

	public Account(int acc_no, String type,double acc_balance, String transaction)
	{	super();
		this.acc_no=acc_no;
		this.type=accType.valueOf(type);
		this.acc_balance=acc_balance;
		this.transactionDetails=transaction;
	}

	public Account(int acc_no,String type, double acc_balance) {
		super();
		this.acc_no=acc_no;
		this.type=accType.valueOf(type);
		
		this.acc_balance = acc_balance;
	
	}


	public String getType() {
		String str=type.name();
		return str;
	}


	public void setType(accType type) {
		this.type = type;
	}


	public double getAcc_balance() {
		return acc_balance;
	}


	public  void setAcc_no(int acc_no1) {
		this.acc_no = acc_no1;
	}


	public void setAcc_balance(double acc_balance) {
		this.acc_balance = acc_balance;
	}

	

	public String getTransactionDetails() {
		return transactionDetails;
	}


	public void setTransactionDetails(String transactionDetails) {
		this.transactionDetails = this.transactionDetails+" "+transactionDetails+"\n";
	}


	public int getAcc_no() {
		return acc_no;
	}



	@Override
	public String toString() {
		return "Account Number:" + acc_no + "\nAccount Type=" + type + "\nAccount Balance:" + acc_balance ;
	}
	

	
}


