package ui;

import java.util.Scanner;

import javax.persistence.Persistence;

import bean.Account;
import bean.Customer;
import exception.BankException;
//import service.ServiceAccClass;
import service.ServiceAccClass;

public class UserInterface {
	static int account_number=1000;


	static ServiceAccClass sac=new ServiceAccClass();

	static  Scanner sc=new Scanner(System.in);
    static Customer c = new Customer();

    public static void main(String args[]) throws BankException {
		
		
    	char y;
    	int j=0;

		do{
			
			System.out.println("MENU\n1.CREATE ACCOUNT\n2.SHOW BALANCE\n3.DEPOSIT\n4.WITHDRAW\n5.FUND TRANSFER\n6.PRINT TRANSACTION\n7.EXIT");
			int ch=sc.nextInt();
		
			
			
			if(ch==1)
			{
				j=1;
			}
			
			//check whether it will create account first.
			while(j!=1)
			{
				if(ch==7)		//IF user directly want to exit
				{
					System.out.println("EXIT FROM APPLICATION");
					System.exit(0);	//Exit from application
				}
				System.out.println("YOU FIRST HAVE TO CREATE ACCOUNT.");
				System.out.println("MENU\n1.CREATE ACCOUNT\n2.SHOW BALANCE\n3.DEPOSIT\n4.WITHDRAW\n5.FUND TRANSFER\n6.PRINT TRANSACTION\n7.EXIT");
				 ch=sc.nextInt();
				 
				 if(ch==1)		//if user want to create account then set j=1;
					 j=1;

			}
		
			
			
		switch(ch){
		
		case 1:
			createAccount();
				break;
		case 2:
				showBalance();
				break;
				
		case 3:
				deposit();
				break;
		case 4:
				withdraw();
				break;
				
		case 5:
				fundTransfer();
				break;
				
		case 6:
				printTransactions();
				break;
		case 7:	
			System.out.println("EXIT FROM APPLICATION");
				System.exit(0);
				break;
		default:	
				System.out.println("Wrong choice ... Try again");
		}
		
		System.out.println("Do you want to continue? Y/N?");
		y=sc.next().charAt(0);
		}while(y!='N');
	}
    
	

static void createAccount(){
	
	System.out.println("Enter your Details");
	System.out.println("Enter your NAME");
	Scanner sc=new Scanner(System.in);
	try{
	String nm=sc.nextLine();
		
	System.out.println("Enter your ADDRESS");

	String adr=sc.nextLine();
	System.out.println("Enter your PHONE NUMBER");
	String phone=sc.next();		
	if(phone.length()<10 || phone.length()>10)
		throw new BankException("Mobile Number Entered is not a 10 digit");

	
	System.out.println("Account Type: SAVINGS OR CURRENT");
	
	String type=sc.next().toUpperCase();
	double bln=0;
	
	if(!(type.equals("SAVINGS") || type.equals("CURRENT")))
	{
		throw new BankException("Type not found.Please Try Again (SAVINGS OR CURRENT");
	}
	
	
	if(type.equals("SAVINGS"))    		  //if account type is savings
	{
		System.out.println("Enter the amount you want to deposit...(>1000)");
		
		bln=sc.nextDouble();
	if(bln<1000){							//check whether entered balance to create amount is greater than 1000
			System.out.println("Minimum balance low\nCannnot create Account");
			return ;
	}
	}
	
	else{
		
	System.out.println("Enter amount to deposit  ");
	bln=sc.nextDouble();
	
	
	}
		account_number++;

	Account act=new Account(account_number,type,bln);          //new account has been created
	//System.out.println("Account number : "+act.getAcc_no());
	
	Customer ct=new Customer(nm,adr,phone,act); //new customer is created and account is linked with customer.
	
	sac.storeDetails(ct); //store details into database.
	
	
	}catch(BankException e)
	{
		System.out.println(e);
	}
							
	
	
			
	}


private static void showBalance() throws BankException {
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Account number to show details");
	int acc=sc.nextInt();
	
	boolean	check=sac.checkAccount(acc);  //check whether account already exist or not
	if(check)                             //if account exist
	{
	
	Customer c=new Customer();
	c=sac.getDetails(acc);
	System.out.println(c);
	}
	else
	{
		System.out.println("Account Does not Exist");
	}
}



private static void deposit() throws BankException {
	
	System.out.println("Enter the account number");
	int ac_no = sc.nextInt();
	
	boolean check=sac.checkAccount(ac_no);		 // check account exist or not?
	if(check) //if exist
	{
	
	System.out.println("Enter amount you want to deposit greater than 100");
	double  deposit = sc.nextDouble();
	if(deposit>=100){
	c = sac.deposit(ac_no, deposit);
	//sac.getDetails(ac_no).getAcct().setTransactionDetails("Deposit Amount : "+deposit);
	System.out.println(c.getAcct().getAcc_no()+" has balance " + c.getAcct().getAcc_balance());
	
	}else{
		System.out.println("Less amount to deposit:: Cannot deposit:: Try Again");
		return;
	}
	}
	else										//if account does not exist
	{
		System.out.println("Account Does Not Exist");
	}
	}





private static void withdraw() throws BankException {
	
	
	System.out.println("Enter the account number");
	int ac_no = sc.nextInt();
	

	boolean check=sac.checkAccount(ac_no); //check if account exist or not?
	if(check) //if account exist
	{
	System.out.println("Enter amount you want to withdraw");
	double  withdraw = sc.nextDouble();
	if(sac.getDetails(ac_no).getAcct().getType().equals("SAVINGS")){ //check whether account type is savings
	if(withdraw <(sac.getDetails(ac_no).getAcct().getAcc_balance()-1000)) //check whether given withdraw amount is greater than remaining balance - minimum balance .
	{
		c = sac.withdraw(ac_no, withdraw);
		//sac.getDetails(ac_no).getAcct().setTransactionDetails("withdrawl Amount : " +withdraw);
		
	System.out.println(c.getAcct().getAcc_no()+" has balance " + c.getAcct().getAcc_balance());
	}
	else 
	{
		System.out.println("Less Balance to Withdraw");
	}
	
	}

	else
	{
		c = sac.withdraw(ac_no, withdraw);	
	//	sac.getDetails(ac_no).getAcct().setTransactionDetails("withdrawl Amount : " +withdraw);
		System.out.println(c.getAcct().getAcc_no()+" has balance " + c.getAcct().getAcc_balance());
		
	}
	
	}
	else
	{
		System.out.println("Account Does Not Exist");
	}
}		


private static void fundTransfer() throws BankException {
	System.out.println("Enter Account number from which the money is to be transferred");
	int acc1 = sc.nextInt();
	boolean check;
	check=sac.checkAccount(acc1);  //check account exist or not
	if(check){//if exist
	
	System.out.println("Enter the Account number to which the money needs to be transferred");
	int acc2 = sc.nextInt();
	
	check=sac.checkAccount(acc2);
	if(check) //if second account also exist or not?
	{
	
	System.out.println("ENter the Amount to be transferred");
	double amt = sc.nextDouble();
	if( sac.getDetails(acc1).getAcct().getType().equals("SAVINGS")){
	if(sac.getDetails(acc1).getAcct().getAcc_balance()-1000>amt ){
		
	sac.fundTransfer(acc1, acc2, amt);

	System.out.println("Acount No: "+acc1+" balance:"+sac.getDetails(acc1).getAcct().getAcc_balance());
	System.out.println("Acount No: "+acc2+" balance:"+sac.getDetails(acc2).getAcct().getAcc_balance());

	}
	else
		System.out.println("Minimum balance should be 1000");
	}
	else
	{
		if(sac.getDetails(acc1).getAcct().getAcc_balance()>amt)
		{
			sac.fundTransfer(acc1, acc2, amt);
			System.out.println("Acount No: "+acc1+" balance:"+sac.getDetails(acc1).getAcct().getAcc_balance());
			System.out.println("Acount No: "+acc2+" balance:"+sac.getDetails(acc2).getAcct().getAcc_balance());
		}
		else
			System.out.println("less balance cannot transfer");

		
	}
	}
	else
	{
		System.out.println("Account "+acc2+" Does Not Exist");
	}
	
	}
	

	else
	{
		System.out.println("Account "+acc1+" Does Not Exist");
	}
	
	
}

private static void printTransactions() throws BankException {

	System.out.println("Enter account Number to see transactions");
	
	int acc_no;
	
	acc_no=sc.nextInt();

	if(!sac.checkAccount(acc_no))	//account exist or not has been checked. if account does not exist.
	{
		System.out.println("Account "+acc_no+" Does not Exist");
	}
	
	else		//if account exist. Transactions displayed.
		{
		Customer c =new Customer();
		
		String str= sac.getDetails(acc_no).getAcct().getTransactionDetails();
		if(str!=" ")
		{	
			System.out.print(str);
			
		}
		else
			System.out.println("No transactions yet");
		
		}
		
	
}

}

