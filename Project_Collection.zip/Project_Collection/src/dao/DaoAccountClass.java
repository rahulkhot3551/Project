package dao;

import java.util.HashMap;
import java.util.Map;

import bean.Account;
import bean.Customer;
import exception.BankException;

/*
 * DaoAccountClass Implementation
 * 
 *  @author: Rahul Babu Khot
 * 
 */


public class DaoAccountClass implements DaoAccountIntf{

	static Map< Integer, Customer > m=new HashMap< Integer, Customer >();
	
	/*
	 * getDetails() implementation
	 */
	
	@Override
	public Customer getDetails(int num) throws BankException {
		
	
		
		
		if(m.containsKey(num)){
			Account.setAcc_no(num);
			return	m.get(num);
		

		}
		return null;
		
		
	}
	
	/*
	 * StoreDetails implementation
	 */

	@Override
	public void storeDetails(Customer c) {
				
		
		m.put(c.getAcct().getAcc_no(),  c);
	}
	
	
	/*
	 * updateAccount implementation
	 */

	@Override
	public Customer updateAccount(int ac_no, double amtDeposit) throws BankException {
		Customer temp =  (m.get(ac_no));
		
		double tmp=temp.getAcct().getAcc_balance() + amtDeposit;
		
		temp.getAcct().setAcc_balance(tmp);  
		
		
		return temp;
	}

	/*
	 * withdraw implementation
	 */


	@Override
	public Customer withdraw(int ac_no, double withdraw)  throws BankException{
		Customer temp = m.get(ac_no);

		double tmp = temp.getAcct().getAcc_balance() - withdraw ;
		temp.getAcct().setAcc_balance(tmp);
		
		String msg="\nWithdrawn Amount : "+withdraw;
		
		return temp;
	}
	

	/*
	 * fundTransfer  implementation
	 */


	@Override
	public void fundTransfer(int acc1, int acc2, double amt) {
		Customer temp = m.get(acc1);
		
		temp.getAcct().setAcc_balance(temp.getAcct().getAcc_balance()-amt);


		Customer temp1 = m.get(acc2);
		
		temp1.getAcct().setAcc_balance(temp1.getAcct().getAcc_balance()+amt);


		
	}
	

//	checkAccount implementation
	
	@Override
	public boolean checkAccount(int account_number) {

		
		return m.containsKey(account_number);
	}
	
	
	
	
}
