package service;

import bean.Customer;
import exception.BankException;


/*
 * ServiceACCIntf interface Declaration
 * 
 *  @author: Rahul Babu Khot
 * 
 */


public interface ServiceAccIntf {
	
	/*getDetails declaration
	 * @param account_num number
	 * @return customer object
	 */
	
	Customer getDetails(int account_num) throws BankException;
	
	
	/* StoreDetails declaration
	 * @param Custoner object 
	 * @return
	 */
	
	void storeDetails(Customer c);
	
	/*updateAccount declaration
	 * @param acc_no to deposit
	 * @param amtDeposit amount to be deposited
	 * @return customer object
	 */
		
	Customer updateDetails(int ac_no , double amtDeposit) throws BankException;
	

	/* withdraw declaration
	 * @param acc_num account number from money will be deposited
	 * @param withdraw is amount to be deducted from final amount .
	 * @return customer object
	 */

	Customer withdraw(int acc_num , double withdraw) throws BankException;
	
	/* fundTransfer declaration
	 * @param acc1 account number 1 from which money will be withdrawn
	 * @param acc2 account number to which money will be deposited
	 * @param amt is amount to be transferred.
	 * @return
	 */
	
	
	void fundTransfer(int acc1, int acc2 , double amt);
	
	/*
	 * checkAccount Declaration
	 * @param account_number to be checked whether present in database or not.
	 * @return boolean
	 */
	
	boolean	checkAccount(int account_number);
	
	
	
}
