package service;

import bean.Customer;
import dao.DaoAccountClass;
import exception.BankException;



/*
 * ServiceAccClass Implementation
 * 
 *  @author: Rahul Babu Khot
 * 
 */

public class ServiceAccClass implements ServiceAccIntf {
	
	DaoAccountClass dac=new DaoAccountClass(); // Dao class object created to access methods from Dao class.
	
	/**
	 * Function to get Details of account holder
	 * @param account_num is account number to get details
	 * @throws BankException 
	 * 
	 */
	
	@Override
	public Customer getDetails(int account_num) throws BankException {
					
		return dac.getDetails(account_num);
	}

	
	
	/**
	 * Function to store Details of Account holder
	 * @param customer is object to Store details
	 * 
	 */
	
	@Override
	public void storeDetails(Customer customer) {
		
		dac.storeDetails(customer);
		
	}


	/**
	 * Function to update Details of Account holder
	 * @param ac_no is account number passed
	 * @param amtDeposit is amount you want to deposit
	 * @throws BankException 
	 * 
	 */
	
	@Override
	public Customer updateDetails(int ac_no, double amtDeposit) throws BankException {
		
	return dac.updateAccount(ac_no, amtDeposit); 
	
	}
	
	
	/**
	 * Function to withdraw amount from bank 
	 * @param ac_no from account has been withdrawn.
	 * @param withdrawAmount is amount to be withdrawn . 
	 * @throws BankException 
	 */

	@Override
	public Customer withdraw(int ac_no, double withdrawAmount) throws BankException {
		return dac.withdraw(ac_no, withdrawAmount);

	}
	
	
	/**
	 * Function to transfer funds from one account to another
	 * @param acc1 account number from money will be transferred
	 * @param acc2 account number to money will be transferred
	 * @amt amount to be transferred
	 */

	@Override
	public void fundTransfer(int acc1, int acc2, double amt) {
		dac.fundTransfer(acc1, acc2, amt);
		
	}

/**
 * 	Function to check whether account available in database or not?
 */

	@Override
	public boolean checkAccount(int account_number) {
		
		return dac.checkAccount(account_number);
	}

	
}
