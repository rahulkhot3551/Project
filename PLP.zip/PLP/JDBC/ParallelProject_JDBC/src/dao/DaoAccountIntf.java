package dao;

import bean.Account;
import bean.Customer;
import exception.BankException;



/*
 * DaoAccountIntf Declaration
 * 
 *  @author: Rahul Babu Khot
 * 
 */
public interface DaoAccountIntf  {
	
	/** getDetails declaration
	 * @param account_num number
	 * @return customer object
	 * @throws BankException 
	 */
	Customer getDetails(int account_num) throws BankException  ;
		
	
		/** StoreDetails declaration
		 * @param Customer object 
		 * @return
		 * @throws BankException 
		 */
		
		void storeDetails(Customer customer) throws BankException;
		

		/** updateAccount declaration
		 * @param acc_no to deposit
		 * @param amtDeposit amount to be deposited
		 * @return customer object
		 * @throws BankException 
		 */
		
		Customer updateAccount(int ac_no , double amtDeposit) throws BankException;
		

		/** withdraw declaration
		 * @param acc_num account number from money will be deposited
		 * @param withdraw is amount to be deducted from final amount .
		 * @return customer object
		 * @throws BankException 
		 */
		
		Customer withdraw(int acc_no , double withdraw) throws BankException;
		
		

		/** fundTransfer declaration
		 * @param acc1 account number 1 from which money will be withdrawn
		 * @param acc2 account number to which money will be deposited
		 * @return
		 */
		
		void fundTransfer(int acc1 , int acc2 , double amt);
		
		/**
		 * checkAccount declaration
		 * @param account_number
		 * @return
		 */
		
		boolean checkAccount(int account_number);

}
