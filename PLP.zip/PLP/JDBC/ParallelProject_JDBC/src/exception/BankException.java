package exception;

public class BankException extends Exception {
	
	/**
	* Thrown exceptions will be catched by this Exception class
	**/
	
	
	public BankException(){
		super();
	}
	
	public BankException(String msg)
	{		
		super(msg);
	}

}
