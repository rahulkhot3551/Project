package bean;

import java.io.Serializable;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.metamodel.StaticMetamodel;

@Entity
public class Customer implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int cust_no;
	private String name;
	private String address;
	private String phone;
	
	@Embedded
	Account acct;
	
	
	
	public Customer() {
		super();
	}

	public Customer(String name, String address, String phone, Account acct) {
		super();
		this.name = name;
		this.address = address;
		this.phone = phone;
		this.acct = acct;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public int getCust_no() {
		return cust_no;
	}

	public void setCust_no(int cust_no) {
		this.cust_no = cust_no;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	

	public Account getAcct() {
		return acct;
	}

	public void setAcct(Account acct) {
		this.acct = acct;
	}

	@Override
	public String toString() {
		return "Customer_No: " + cust_no +"\nName: " + name + " \nAddress : " + address + "\nPhone Number: " + phone +"\n" + acct  ;
	}


	
}
