package exception;

public class BankException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	* Thrown exceptions will be catched by this Exception class
	**/
	
	
	public BankException(){
		super();
	}
	
	public BankException(String msg)
	{
		super(msg);
	}

}
