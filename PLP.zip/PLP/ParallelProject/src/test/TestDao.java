package test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import bean.Account;
import bean.Customer;
import dao.DaoAccountClass;
import exception.BankException;

public class TestDao {

static	Account account = new Account(1000, "SAVINGS", 10000, "");
static	Customer customer1 = new Customer("Rahul", "abcd", "8308899231", account);



	private DaoAccountClass dao;
	private Customer customer;
	@Before
	public void init(){
		dao=new DaoAccountClass();
		customer=new Customer();

		dao.storeDetails(customer1);
		
		
	}
	
	@Test
	public void testSaveDetails() throws BankException{
		
		
		
		customer1=dao.getDetails(1000);
		assertTrue(customer1!=null);
		
		
	}
	
	@Test
	public void testGetDetails() throws BankException{
	
	
		
		customer=dao.getDetails(1000);
		
		assertEquals(customer1,customer);
		
		
	}
	
	@Test
	public void testDeposit() throws BankException{
	
			
		Customer cust=new Customer();
		
		cust= dao.updateAccount(1000, 500);   //Deposited value 500
			
		assertEquals(10000.0,cust.getAcct().getAcc_balance(),0.0001); //checked if equals ..If not then deposited successfully
		
	}
	
	@Test
	public void testWithdraw() throws BankException{
		

				
		
		
		customer=dao.withdraw(1000, 500);
		
		
		assertEquals(9500,customer.getAcct().getAcc_balance(),0.0001);
		
	}
		
	@Test
	public void testCheckAccount(){
	
		assertTrue(dao.checkAccount(1000));
		
	}
	
	

}
