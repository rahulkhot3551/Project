package dao;

import bean.Account;
import bean.Customer;



/*
 * DaoAccountIntf Declaration
 * 
 *  @author: Rahul Babu Khot
 * 
 */
public interface DaoAccountIntf {
	
	/** getDetails declaration
	 * @param account_num number
	 * @return customer object
	 */
	Customer getDetails(int account_num);
		
	
		/** StoreDetails declaration
		 * @param Custoner object 
		 * @return
		 */
		
		void storeDetails(Customer customer);
		

		/** updateAccount declaration
		 * @param acc_no to deposit
		 * @param amtDeposit amount to be deposited
		 * @return customer object
		 */
		
		Customer updateAccount(int ac_no , double amtDeposit);
		

		/** withdraw declaration
		 * @param acc_num account number from money will be deposited
		 * @param withdraw is amount to be deducted from final amount .
		 * @return customer object
		 */
		
		Customer withdraw(int acc_no , double withdraw);
		
		

		/** fundTransfer declaration
		 * @param acc1 account number 1 from which money will be withdrawn
		 * @param acc2 account number to which money will be deposited
		 * @return
		 */
		
		void fundTransfer(int acc1 , int acc2 , double amt);
		
		/**
		 * checkAccount declaration
		 * @param account_number
		 * @return
		 */
		
		boolean checkAccount(int account_number);

}
