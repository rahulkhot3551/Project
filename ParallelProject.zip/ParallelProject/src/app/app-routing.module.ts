import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

import { CreateComponent } from './create/create.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { PrintComponent } from './print/print.component';


const routes:Routes=[
  {path:'',redirectTo:'/', pathMatch:'full'} ,
  {path:'create',component:CreateComponent},
  {path:'showBalance',component:ShowBalanceComponent},
  {path:'deposit',component:DepositComponent},
  {path:'withdraw',component:WithdrawComponent},
  {path:'Fund Transfer',component:FundTransferComponent},
  {path:'print',component:PrintComponent}
];

@NgModule({
  imports: [CommonModule,
    RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
