import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateComponent } from './create/create.component';
import {FormsModule,FormArray} from '@angular/forms'
import {HttpClientModule,HttpClient} from '@angular/common/http';

import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { PrintComponent } from './print/print.component'
import {APP_BASE_HREF} from '@angular/common';





@NgModule({
  declarations: [
    AppComponent,
    CreateComponent,
    ShowBalanceComponent,
    DepositComponent,
    WithdrawComponent,
    FundTransferComponent,
    PrintComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,HttpClientModule
  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
