package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import bean.Account;
import bean.Customer;
import exception.BankException;
import util.JdbcImpl;

/*
 * DaoAccountClass Implementation
 * 
 *  @author: Rahul Babu Khot
 * 
 */


public class DaoAccountClass implements DaoAccountIntf{
	
	static int counter=0;

	
	/*
	 * getDetails() implementation using JDBC
	 */
	
	@Override
	public Customer getDetails(int num) throws BankException {
		
		Connection conn = null;
		try{
			
			conn = JdbcImpl.getConnection(); //Getting connection object from JdbcImpl class
			String sql = "select * from customer where account_number=" + num; //query to get all values from table customer.
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			Customer c=null;
			
			while(rs.next()) {
				
				
				
				String name,address,phone,type,transactions;
				int acc_no;
				double balance;
				name=rs.getString(1);
				address=rs.getString(2);
				phone=rs.getString(3);
				type=rs.getString(5);
				acc_no=rs.getInt(4);
				balance=rs.getDouble(6);
				transactions=rs.getString(7);
				
				Account ac=new Account(type,balance);
				 c=new Customer(name,address,phone,ac);
				 ac.setAcc_no(num); 
				 ac.setTransactionDetails(transactions);
				
				
			}
			
			
			if(c==null)
			{
				throw new BankException("Account holder with account number "+c.getAcct().getAcc_no()+" Does not exist in database");
			}
			else			
			return c;
			
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();			//Closing Connection
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

				
	
		return null;
		
		
	}
	
	/*
	 * StoreDetails implementation
	 */

	@Override
	public void storeDetails(Customer c) throws BankException {
		
		counter++;
		Connection tempConn;
		if(counter==1){
			
			if(counter==1)
			{
				try {
					tempConn = JdbcImpl.getConnection();
					String sql3 ="TRUNCATE TABLE CUSTOMER";
					Statement stmt3 = tempConn.createStatement();
					stmt3.execute(sql3);
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		Connection conn = null;
		
		try {
			
			conn = JdbcImpl.getConnection();
			

			
			String sql = "insert into CUSTOMER values(?,?,?,?,?,?,?)";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, c.getName());
			stmt.setString(2, c.getAddress());
			stmt.setString(3, c.getPhone());
			stmt.setInt(4, c.getAcct().getAcc_no());
			stmt.setString(5,c.getAcct().getType());
			stmt.setDouble(6, c.getAcct().getAcc_balance());
			stmt.setString(7, " ");
			
			stmt.executeUpdate();

			
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}}
			
	

	
	/*
	 * updateAccount implementation
	 */

	@Override
	public Customer updateAccount(int ac_no, double amtDeposit) throws BankException {
		
		Connection conn = null;
		try{
			
			double value=0;
			conn = JdbcImpl.getConnection();
			String trans="";
			String sql = "select * from customer where account_number=" + ac_no;
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
			value=rs.getDouble(6);
			trans=rs.getString(7);
			}
			
			
			String sql2 = "Update customer SET account_balance=?, transaction_details=? where account_number=" + ac_no;
			PreparedStatement stmt1 = conn.prepareStatement(sql2);
			String msg="\nDeposit Amount : "+amtDeposit;
			double value1= value +amtDeposit;
			trans=trans+" "+msg;
			stmt1.setDouble(1,value1);
			stmt1.setString(2, trans);
			
			stmt1.executeUpdate();
		
		
			return getDetails(ac_no);
			
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return null;

		
	/*	
		Customer temp =  (m.get(ac_no));
		double tmp=temp.getAcct().getAcc_balance() + amtDeposit;
		
		temp.getAcct().setAcc_balance(tmp);  
		return temp;
		*/
	}

	/*
	 * withdraw implementation
	 */


	@Override
	public Customer withdraw(int ac_no, double withdraw) throws BankException {
		
		Connection conn = null;

		try{
			
			double value=0;
			conn = JdbcImpl.getConnection();
			String trans="";
			String sql = "select * from customer where account_number=" + ac_no;
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
			value=rs.getDouble(6);
			trans=rs.getString(7);
			
			}
			String sql2 = "Update customer SET account_balance=?, transaction_details=? where account_number=" + ac_no;
			PreparedStatement stmt1 = conn.prepareStatement(sql2);
			String msg="\nWithdrawn Amount : "+withdraw;
			
			double value1= value - withdraw;
			trans=trans+" "+msg;

			
			stmt1.setDouble(1,value1);
			stmt1.setString(2, trans);
			
			stmt1.executeUpdate();
		
			return getDetails(ac_no);
			
			
			

		
		}catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
		
		return null;
						
	}
	

	/*
	 * fundTransfer  implementation
	 */


	@Override
	public void fundTransfer(int acc1, int acc2, double amt) {
		Connection conn=null;
		
		try{
			
			
		double value=0;
		conn = JdbcImpl.getConnection();
		String trans="";
		String sql = "select * from customer where account_number=" + acc1;
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		while(rs.next()){
		value=rs.getDouble(6);
		trans=rs.getString(7);		
		}
		
		
		String sql2 = "Update customer SET account_balance=?, transaction_details=? where account_number=" + acc1;
		PreparedStatement stmt1 = conn.prepareStatement(sql2);
		String msg="\nTransferred Amount : "+amt;
		
		double value1= value - amt;
		trans=trans+" "+msg;

		
		stmt1.setDouble(1,value1);
		stmt1.setString(2, trans);
		
		stmt1.executeUpdate();
	

		
		
		
		double value2=0;
		String trans2="";
		String sql3 = "select * from customer where account_number=" + acc2;
		Statement stmt2 = conn.createStatement();
		ResultSet rs2 = stmt.executeQuery(sql3);
		while(rs2.next()){
		value2=rs2.getDouble(6);
		trans2=rs2.getString(7);
		}
		
		
		String sql4 = "Update customer SET account_balance=?, transaction_details=? where account_number=" + acc2;
		PreparedStatement stmt3 = conn.prepareStatement(sql4);
		String msg1="\nDeposit Amount By Transfer : "+amt;
		 value2= value2 +amt;
		trans2=trans2+" "+msg1;
		stmt3.setDouble(1,value2);
		stmt3.setString(2, trans2);
		
		stmt3.executeUpdate();
	

	
		
		
		
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		
	}
	

//	checkAccount implementation
	
	@Override
	public boolean checkAccount(int account_number) {

		Connection con=null;
		try{
			
		con = JdbcImpl.getConnection();
		String sql = "select * from customer where account_number=" + account_number;
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		if(rs.next())
		{
			return true;
		}
		
		
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		
		return false;
	}
	
	
	
	
}
